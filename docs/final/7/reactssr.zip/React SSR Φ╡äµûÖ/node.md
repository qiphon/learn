# React SSR

## 服务端渲染到同构之路

## SSR

- 打包环境区分
    - 将react 部分代码，单独打包，在node引用
    - gulp
- router
- 样式处理
    - isomorphic-style-loader
- 注水，脱水
- 安全
- 性能优化
    - 页面缓存 组件及缓存
    - 接口缓存
    - next 体验

