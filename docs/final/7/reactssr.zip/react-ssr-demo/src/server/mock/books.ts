export const booksList = [
  { id: 1, title: "后端返回的数据1" },
  { id: 2, title: "后端返回的数据2" },
  { id: 3, title: "后端我们使用了BFF层" },
  { id: 4, title: "Webpack使用了最新版本" },
  { id: 5, title: "Webpack使用了最新版本" },
];

export const booksDetails = [
  { id: 1, url: "https://www.amazon.com/Elad-Elrom/e/B003XE8ICW" },
  { id: 2, url: "https://www.amazon.com/gp/product/B07VMD99YH/" },
  { id: 3, url: "https://www.amazon.com/gp/product/B01N5AIZ7G/" },
  { id: 4, url: "https://www.amazon.com/gp/product/B004VH5YZY" },
  { id: 5, url: "https://www.amazon.com/gp/product/1430219041" },
];
