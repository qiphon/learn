declare interface Window {
    __INITIAL__DATA__?: any
}
