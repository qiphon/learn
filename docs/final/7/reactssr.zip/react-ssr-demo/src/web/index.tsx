import React from 'react';
import ReactDOM from 'react-dom';
import {ClientApp} from '@pages/App';
ReactDOM.hydrate(<ClientApp />, document.getElementById('main'));