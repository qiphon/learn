import React from "react";
const NotFound = () => {
  return (
    <>
      <div className='components-notfound'>我是404</div>
    </>
  );
};
export default NotFound;
