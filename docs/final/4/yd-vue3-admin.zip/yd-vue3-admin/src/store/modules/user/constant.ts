// const GET_DATA = 'getData'; //Symbol.for('getData');
enum USER_CONSTANT {
  GET_DATA = 'getData',
  DONE = 'DONE',
  DOING = 'DOING',
}
export default USER_CONSTANT;
