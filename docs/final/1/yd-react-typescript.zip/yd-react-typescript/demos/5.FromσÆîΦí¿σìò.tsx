//✯✯✯✯✯✯✯✯✯✯✯✯---1.简单直接的内联事件----✯✯✯✯✯✯✯✯✯✯✯✯✯✯
//❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄
const onChange = (e: React.FormEvent<HTMLInputElement>): void => {
  this.setState({ text: e.currentTarget.value });
};
//更美观一点
// const onChange2= React.ChangeEventHandler<HTMLInputElement> = (e) => {
//     this.setState({text: e.currentTarget.value})
//   }
function App() {
  return <input type="text" value={this.state.text} onChange={onChange} />;
}

//要是不很特别关心你的事件名的话 可以直接 如下

// <form
//   ref={formRef}
//   onSubmit={(e: React.SyntheticEvent) => {
//     e.preventDefault();
//     const target = e.target as typeof e.target & {
//       email: { value: string };
//       password: { value: string };
//     };
//     const email = target.email.value; // typechecks!
//     const password = target.password.value; // typechecks!
//     // etc...
//   }}
// >
//   <div>
//     <label>
//       Email:
//       <input type="email" name="email" />
//     </label>
//   </div>
//   <div>
//     <label>
//       Password:
//       <input type="password" name="password" />
//     </label>
//   </div>
//   <div>
//     <input type="submit" value="Log in" />
//   </div>
// </form>;
