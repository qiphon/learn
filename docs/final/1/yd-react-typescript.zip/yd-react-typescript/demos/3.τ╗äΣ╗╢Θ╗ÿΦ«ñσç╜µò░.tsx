import React from 'react';

//✯✯✯✯✯✯✯✯✯✯✯✯---1.defaultProps可有可无----✯✯✯✯✯✯✯✯✯✯✯✯✯✯
//❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄
//JSX.Element ->返回值 React.createElement
// React.ReactNode ->组件的返回值
type GreetProps = { age?: number };
const Greet = ({ age = 21 }: GreetProps) => <h1>{age}</h1>;

//✯✯✯✯✯✯✯✯✯✯✯✯---2.默认defaultProps----✯✯✯✯✯✯✯✯✯✯✯✯✯✯
//❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄
// type GreetProps1 = { age: number } & typeof defaultProps;
// const defaultProps = {
//   age: 21,
// };

// const Greet2 = (props: GreetProps1) => <h1>{props.age}</h1>;
// Greet.defaultProps = defaultProps;

interface IProps {
  name: string;
}
const defaultProps = {
  age: 25,
};
const GreetComponent = ({ name, age }: IProps & typeof defaultProps) => (
  <div>{`Hello, my name is ${name}, ${age}`}</div>
);
GreetComponent.defaultProps = defaultProps;

const TestComponent = (props: React.ComponentProps<typeof GreetComponent>) => {
  return <h1 />;
};

// 这里就必须带上age
const el = <TestComponent name="foo" age={18} />;

type ComponentProps<T> = T extends
  | React.ComponentType<infer P>
  | React.Component<infer P>
  ? JSX.LibraryManagedAttributes<T, P>
  : never;

const TestComponent2 = (props: ComponentProps<typeof GreetComponent>) => {
  return <h1 />;
};

// No error
const el2 = <TestComponent2 name="foo" />;
