// allowSyntheticDefaultImports; 避免 * as 的局面
type AppProps = { message: string }; /* 也可以换成interface*/
const App = ({ message }: AppProps) => <div>{message}</div>;
//显示指定函数组件
const App2: React.FunctionComponent<{ message: string }> = ({ message }) => (
  <div>{message}</div>
);
//默认涵盖的children
const Title: React.FunctionComponent<{ title: string }> = ({
  children,
  title,
}) => <div title={title}>{children}</div>;

//功能组件只能返回JSX表达式或JSX表达式null 报错的组件
// const MyConditionalComponent = ({ shouldRender = false }) =>
//   shouldRender ? <div /> : false;
// const el = <MyConditionalComponent />;

// const MyArrayComponent = () => Array(5).fill(<div />);
// const el2 = <MyArrayComponent />; // throws an error

const MyArrayComponent = () =>
  (Array(5).fill(<div />) as unknown) as JSX.Element;
