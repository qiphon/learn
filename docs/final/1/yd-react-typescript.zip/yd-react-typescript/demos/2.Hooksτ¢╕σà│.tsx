import React, { useEffect, useRef, useImperativeHandle } from 'react';

//✯✯✯✯✯✯✯✯✯✯✯✯---1.useState----✯✯✯✯✯✯✯✯✯✯✯✯✯✯
//❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄

//使用类型推断去判断你的state
const [val, toggle] = React.useState(false);

interface IUser {}
const [user, setUser] = React.useState<IUser | null>(null);

// 稍后你可以这样使用它
// setUser(newUser);

//✯✯✯✯✯✯✯✯✯✯✯✯---2.useReducer----✯✯✯✯✯✯✯✯✯✯✯✯✯✯
//❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄
type AppState = {};
type Action =
  | { type: 'SET_ONE'; payload: string }
  | { type: 'SET_TWO'; payload: number };

export function reducer(state: AppState, action: Action): AppState {
  switch (action.type) {
    case 'SET_ONE':
      return {
        ...state,
        one: action.payload, // `payload` is string
      };
    case 'SET_TWO':
      return {
        ...state,
        two: action.payload, // `payload` is number
      };
    default:
      return state;
  }
}
//带TypeScript版本的Reducer
// import { Reducer } from 'redux';
// export function reducer: Reducer<AppState, Action>() {}

//✯✯✯✯✯✯✯✯✯✯✯✯---3.useEffect----✯✯✯✯✯✯✯✯✯✯✯✯✯✯
//❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄
//useEffect不要返回值 TypeScript and React都会找你麻烦
// function DelayedEffect(props: { timerMs: number }) {
//   const { timerMs } = props;
//   // bad! setTimeout 默认是有返回值的
//   useEffect(() => setTimeout(() => {}, timerMs), [timerMs]);
//   return null;
// }

//✯✯✯✯✯✯✯✯✯✯✯✯---4.useRef----✯✯✯✯✯✯✯✯✯✯✯✯✯✯
//❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄

// !断言在它之前任何表达式都不是null 或者 undefined
const ref1 = useRef<HTMLElement>(null!);
// ref1.current为止读; 现在对ref1确实是null 但是TS不这么认为
const ref2 = useRef<HTMLElement | null>(null);

// function MyComponent() {
//   const ref1 = useRef<HTMLElement>(null!);
//   useEffect(() => {
//     // TypeScript  ref1 && ref1.current
//     doSomethingWith(ref1.current);
//   });
//   return <div ref={ref1}> etc </div>;
// }

function TextInputWithFocusButton() {
  // initialise with null, but tell TypeScript we are looking for an HTMLInputElement
  const inputEl = React.useRef<HTMLInputElement>(null);
  const onButtonClick = () => {
    // strict null checks need us to check if inputEl and current exist.
    // but once current exists, it is of type HTMLInputElement, thus it
    // has the method focus! ✅
    if (inputEl && inputEl.current) {
      inputEl.current.focus();
    }
  };
  return (
    <>
      {/* in addition, inputEl only can be used with input elements. Yay! */}
      <input ref={inputEl} type="text" />
      <button onClick={onButtonClick}>Focus the input</button>
    </>
  );
}

//✯✯✯✯✯✯✯✯✯✯✯✯---6.Custom Hooks----✯✯✯✯✯✯✯✯✯✯✯✯✯✯
//❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄
//useImperativeHandle 可以让你在使用 ref 时自定义暴露给父组件的实例值。
type ListProps<ItemType> = {
  items: ItemType[];
  innerRef?: React.Ref<{ scrollToItem(item: ItemType): void }>;
};

function List<ItemType>(props: ListProps<ItemType>) {
  useImperativeHandle(props.innerRef, () => ({
    scrollToItem() {},
  }));
  return null;
}

//✯✯✯✯✯✯✯✯✯✯✯✯---5.useImperativeHandle----✯✯✯✯✯✯✯✯✯✯✯✯✯✯
//❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄
export function useLoading() {
  const [isLoading, setState] = React.useState(false);
  const load = (aPromise: Promise<any>) => {
    setState(true);
    return aPromise.finally(() => setState(false));
  };
  //自定义的hook返回数组的时候 要避免类型推断
  // infers [boolean, typeof load] instead of (boolean | typeof load)[]
  return [isLoading, load] as const;
}

//当const解决不了你的问题的时候
export function useLoading2() {
  const [isLoading, setState] = React.useState(false);
  const load = (aPromise: Promise<any>) => {
    setState(true);
    return aPromise.finally(() => setState(false));
  };
  return [isLoading, load] as [
    boolean,
    (aPromise: Promise<any>) => Promise<any>
  ];
}
//辅助函数
function tuplify<T extends any[]>(...elements: T) {
  return elements;
}

function useArray() {
  const numberValue = useRef(3).current;
  const functionValue = useRef(() => {}).current;
  return [numberValue, functionValue]; // type is (number | (() => void))[]
}

function useTuple() {
  const numberValue = useRef(3).current;
  const functionValue = useRef(() => {}).current;
  return tuplify(numberValue, functionValue); // type is [number, () => void]
}
//react团队的建议是如果返回2个以上 不要用tuples 用object
