import * as React from 'react';

//✯✯✯✯✯✯✯✯✯✯✯✯---1.简单的例子（给就嗲发的版本中有）----✯✯✯✯✯✯✯✯✯✯✯✯✯✯
//❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄
interface AppContextInterface {
  name: string;
  author: string;
  url: string;
}

const AppCtx = React.createContext<AppContextInterface | null>(null);

// Provider in your app

const sampleAppContext: AppContextInterface = {
  name: 'Using React Context in a Typescript App',
  author: 'thehappybug',
  url: 'http://www.example.com',
};

export const App = () => (
  <AppCtx.Provider value={sampleAppContext}>...</AppCtx.Provider>
);

// Consume in your app

export const PostInfo = () => {
  const appContext = React.useContext(AppCtx);
  return (
    <div>
      Name: {appContext.name}, Author: {appContext.author}, Url:{' '}
      {appContext.url}
    </div>
  );
};

//✯✯✯✯✯✯✯✯✯✯✯✯---2.简单的例子（给就嗲发的版本中有）----✯✯✯✯✯✯✯✯✯✯✯✯✯✯
//❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄❄
interface ContextState {
  // set the type of state you want to handle with context e.g.
  name: string | null;
}
//默认值
const Context = React.createContext({} as ContextState);
const currentUserContext = React.createContext<string | undefined>(undefined);

function EnthusasticGreeting() {
  const currentUser = React.useContext(currentUserContext);
  return <div>HELLO {currentUser!.toUpperCase()}!</div>;
}

function App() {
  return (
    <currentUserContext.Provider value="Anders">
      <EnthusasticGreeting />
    </currentUserContext.Provider>
  );
}

//给一个默认值他不认的时候 我们可以用感叹号强行过滤掉他的检查
// const currentUserContext = React.createContext<string | undefined>(undefined);
// const currentUserContext = React.createContext<string>(undefined!);

import * as React from 'react';

function createCtx<A extends {} | null>() {
  const ctx = React.createContext<A | undefined>(undefined);
  function useCtx() {
    const c = React.useContext(ctx);
    if (c === undefined)
      throw new Error('useCtx must be inside a Provider with a value');
    return c;
  }
  return [useCtx, ctx.Provider] as const; // 'as const' makes TypeScript infer a tuple
}

export const [useCurrentUserName, CurrentUserProvider] = createCtx<string>();
