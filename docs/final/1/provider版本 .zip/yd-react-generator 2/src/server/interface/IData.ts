export interface IData {
  data: string;
  result?: Array<number | string>;
}
