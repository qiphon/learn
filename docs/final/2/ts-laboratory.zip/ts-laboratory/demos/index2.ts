import ydkey from './ydkey';
const obj = {
  [ydkey]() {
    console.log(123);
  },
};
export default obj;
