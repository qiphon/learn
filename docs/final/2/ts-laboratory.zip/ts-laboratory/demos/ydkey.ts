const ydkey = Symbol.for('yideng');
export default ydkey;
