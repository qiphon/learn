// import injectSheet from 'react-jss'
import * as React from "react";
const Demo = () => {
  return (
    <div className="components-home">
        <h2>
          <span>关于我们</span>
        </h2>
    </div>
  );
};
export default Demo;
