(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["demo"],{

/***/ "./src/web/components/demo/index.tsx":
/*!*******************************************!*\
  !*** ./src/web/components/demo/index.tsx ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"./node_modules/_react@16.9.0@react/index.js\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);\n\n\nconst Demo = () => {\n  return react__WEBPACK_IMPORTED_MODULE_0__[\"createElement\"](\"div\", {\n    className: \"components-home\"\n  }, react__WEBPACK_IMPORTED_MODULE_0__[\"createElement\"](\"h2\", null, react__WEBPACK_IMPORTED_MODULE_0__[\"createElement\"](\"span\", null, \"\\u5173\\u4E8E\\u6211\\u4EEC\")));\n};\n\n/* harmony default export */ __webpack_exports__[\"default\"] = (Demo);\n\n//# sourceURL=webpack:///./src/web/components/demo/index.tsx?");

/***/ })

}]);