import React from 'react';
import ReactDOM from 'react-dom';
import 'mobx-react-lite/batchingForReactDom';
import App from '@pages/App';
// import 'mobx-react-lite/batchingForReactDom';

ReactDOM.render(<App />, document.getElementById('main'));
