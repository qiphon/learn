cross-env NODE_ENV=development ts-node-dev --respawn --transpile-only dist/app.ts
# supervisor ./dist/app.js
