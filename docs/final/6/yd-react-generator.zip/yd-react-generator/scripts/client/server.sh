webpack serve --mode development
#npm install -g npm-check-updates
# webpack-dev-server --mode development --open