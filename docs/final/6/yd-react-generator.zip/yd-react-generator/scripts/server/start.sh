cross-env NODE_ENV=development ts-node-dev --respawn --transpile-only src/server/app.ts
# supervisor ./dist/app.js
