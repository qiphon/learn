# 🚆gulp 开发环境
cross-env NODE_ENV=development gulp