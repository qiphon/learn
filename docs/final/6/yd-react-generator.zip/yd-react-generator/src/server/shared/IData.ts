export interface IData {
  item: string;
  result?: Array<number | string>;
}
