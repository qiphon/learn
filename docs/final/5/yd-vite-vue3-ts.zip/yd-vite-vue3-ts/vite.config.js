const { resolve } = require('path');
module.exports = {
  alias: {
    '/@/': resolve(__dirname, './src'),
  },
};
