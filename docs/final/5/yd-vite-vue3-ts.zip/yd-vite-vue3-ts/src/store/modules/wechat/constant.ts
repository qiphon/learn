// const USER_CONSTANT = {
//   GET_DATA: 'getData',
// };
const SET_DATA = 'setData';
export { SET_DATA };
