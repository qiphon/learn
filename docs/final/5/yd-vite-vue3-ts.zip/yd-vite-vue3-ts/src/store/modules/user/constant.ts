// const USER_CONSTANT = {
//   GET_DATA: 'getData',
// };
const GET_DATA = 'getData';
export { GET_DATA };
