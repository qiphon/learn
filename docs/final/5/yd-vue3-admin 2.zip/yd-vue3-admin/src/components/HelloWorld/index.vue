<template>
  <h1>{{ msg }}</h1>
  <button @click="count++">count is: {{ count }}</button>
  <h4>🐻Vuex状态管理</h4>
  <p>
    <code>{{ article }}</code>
    <button @click="setData">修改状态</button>
  </p>
</template>

<script lang="ts" src="./index.ts"></script>

<style lang="postcss" scoped>
h1 {
  --helloColor: orange;
  color: var(--helloColor);
}
p {
  & code {
    color: green;
  }
}
</style>
