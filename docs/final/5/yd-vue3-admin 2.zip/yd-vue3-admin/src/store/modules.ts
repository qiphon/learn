import user from './modules/user';
import wechat from './modules/wechat';

const modules = {
  user,
  wechat,
};
export default modules;
export { modules };
