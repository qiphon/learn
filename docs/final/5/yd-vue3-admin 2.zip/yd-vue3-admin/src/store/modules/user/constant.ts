// const GET_DATA = 'getData'; //Symbol.for('getData');
// eslint-disable-next-line no-shadow
const GET_DATA = 'getData';
const DONE = 'done';
const DOING = 'DOING';

// const USER_CONSTANT = {
//   GET_DATA: 'getData',
//   DONE: 'done',
//   DOING: 'DOING',
// };
export { GET_DATA, DONE, DOING };
