====单元测试===
1.安装单元测试框架
cnpm install karma --save-dev
package.json里 
初始化 karma init
运行   karma start
2.断言库
npm install karma-jasmine  jasmine-core --save-dev
3.npm install karma karma-coverage --save-dev

===UI测试===
npm install -g backstopjs
backstop init 
backstop test

===e2e测试===
UI Recorder

===service测试===
nodejs api结果不符合
