//describe+it完善了测试用例
//断言库 expect api
describe("第一个单元测试", function() {
    it("测试+1函数", function () {
        expect(add(1)).toBe(4);
        expect(add(2)).toBe(3);
    });
});
