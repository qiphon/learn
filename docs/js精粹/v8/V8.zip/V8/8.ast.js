var test = 'laoyuan'

function init(str){
	//console.log(str)
}

for(var i=0;i<10000;i++){
   init(test);
}

/*
*mac平台:
https://storage.googleapis.com/chromium-v8/official/canary/v8-mac64-dbg-8.4.109.zip
linux32平台:
https://storage.googleapis.com/chromium-v8/official/canary/v8-linux32-dbg-8.4.109.zip
linux64平台:
https://storage.googleapis.com/chromium-v8/official/canary/v8-linux64-dbg-8.4.109.zip
win32平台:
https://storage.googleapis.com/chromium-v8/official/canary/v8-win32-dbg-8.4.109.zip
win64平台:
https://storage.googleapis.com/chromium-v8/official/canary/v8-win64-dbg-8.4.109.zip
*/
