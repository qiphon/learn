﻿namespace 解释器模式
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.axC = new AxWMPLib.AxWindowsMediaPlayer();
            this.timerMain = new System.Windows.Forms.Timer(this.components);
            this.button11 = new System.Windows.Forms.Button();
            this.axD = new AxWMPLib.AxWindowsMediaPlayer();
            this.axE = new AxWMPLib.AxWindowsMediaPlayer();
            this.axCH1 = new AxWMPLib.AxWindowsMediaPlayer();
            this.axG = new AxWMPLib.AxWindowsMediaPlayer();
            this.axA = new AxWMPLib.AxWindowsMediaPlayer();
            this.axGL1 = new AxWMPLib.AxWindowsMediaPlayer();
            this.axAL1 = new AxWMPLib.AxWindowsMediaPlayer();
            this.axBL1 = new AxWMPLib.AxWindowsMediaPlayer();
            this.axB = new AxWMPLib.AxWindowsMediaPlayer();
            this.axF = new AxWMPLib.AxWindowsMediaPlayer();
            this.btnSHT = new System.Windows.Forms.Button();
            this.btnYXDCB = new System.Windows.Forms.Button();
            this.axCL1 = new AxWMPLib.AxWindowsMediaPlayer();
            this.axDL1 = new AxWMPLib.AxWindowsMediaPlayer();
            this.axEL1 = new AxWMPLib.AxWindowsMediaPlayer();
            this.axFL1 = new AxWMPLib.AxWindowsMediaPlayer();
            this.axFH1 = new AxWMPLib.AxWindowsMediaPlayer();
            this.axBH1 = new AxWMPLib.AxWindowsMediaPlayer();
            this.axGH1 = new AxWMPLib.AxWindowsMediaPlayer();
            this.axAH1 = new AxWMPLib.AxWindowsMediaPlayer();
            this.axEH1 = new AxWMPLib.AxWindowsMediaPlayer();
            this.axDH1 = new AxWMPLib.AxWindowsMediaPlayer();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.axCL2 = new AxWMPLib.AxWindowsMediaPlayer();
            this.axDL2 = new AxWMPLib.AxWindowsMediaPlayer();
            this.axEL2 = new AxWMPLib.AxWindowsMediaPlayer();
            this.axFL2 = new AxWMPLib.AxWindowsMediaPlayer();
            this.axGL2 = new AxWMPLib.AxWindowsMediaPlayer();
            this.axAL2 = new AxWMPLib.AxWindowsMediaPlayer();
            this.axBL2 = new AxWMPLib.AxWindowsMediaPlayer();
            this.axEH3 = new AxWMPLib.AxWindowsMediaPlayer();
            this.axDH3 = new AxWMPLib.AxWindowsMediaPlayer();
            this.axCH3 = new AxWMPLib.AxWindowsMediaPlayer();
            this.axFH2 = new AxWMPLib.AxWindowsMediaPlayer();
            this.axBH2 = new AxWMPLib.AxWindowsMediaPlayer();
            this.axGH2 = new AxWMPLib.AxWindowsMediaPlayer();
            this.axAH2 = new AxWMPLib.AxWindowsMediaPlayer();
            this.axEH2 = new AxWMPLib.AxWindowsMediaPlayer();
            this.axDH2 = new AxWMPLib.AxWindowsMediaPlayer();
            this.axCH2 = new AxWMPLib.AxWindowsMediaPlayer();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtMain = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtChord = new System.Windows.Forms.TextBox();
            this.timerChord = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.axC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axCH1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axG)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axGL1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axAL1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axBL1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axF)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axCL1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDL1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axEL1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axFL1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axFH1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axBH1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axGH1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axAH1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axEH1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDH1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axCL2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDL2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axEL2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axFL2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axGL2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axAL2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axBL2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axEH3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDH3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axCH3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axFH2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axBH2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axGH2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axAH2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axEH2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDH2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axCH2)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // axC
            // 
            this.axC.Enabled = true;
            this.axC.Location = new System.Drawing.Point(61, 203);
            this.axC.Name = "axC";
            this.axC.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axC.OcxState")));
            this.axC.Size = new System.Drawing.Size(112, 46);
            this.axC.TabIndex = 0;
            // 
            // timerMain
            // 
            this.timerMain.Tick += new System.EventHandler(this.timerMain_Tick);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(834, 540);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(48, 23);
            this.button11.TabIndex = 12;
            this.button11.Text = "播放";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // axD
            // 
            this.axD.Enabled = true;
            this.axD.Location = new System.Drawing.Point(179, 203);
            this.axD.Name = "axD";
            this.axD.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axD.OcxState")));
            this.axD.Size = new System.Drawing.Size(112, 46);
            this.axD.TabIndex = 13;
            // 
            // axE
            // 
            this.axE.Enabled = true;
            this.axE.Location = new System.Drawing.Point(297, 203);
            this.axE.Name = "axE";
            this.axE.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axE.OcxState")));
            this.axE.Size = new System.Drawing.Size(112, 46);
            this.axE.TabIndex = 14;
            // 
            // axCH1
            // 
            this.axCH1.Enabled = true;
            this.axCH1.Location = new System.Drawing.Point(61, 255);
            this.axCH1.Name = "axCH1";
            this.axCH1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axCH1.OcxState")));
            this.axCH1.Size = new System.Drawing.Size(112, 46);
            this.axCH1.TabIndex = 17;
            // 
            // axG
            // 
            this.axG.Enabled = true;
            this.axG.Location = new System.Drawing.Point(533, 203);
            this.axG.Name = "axG";
            this.axG.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axG.OcxState")));
            this.axG.Size = new System.Drawing.Size(112, 46);
            this.axG.TabIndex = 16;
            // 
            // axA
            // 
            this.axA.Enabled = true;
            this.axA.Location = new System.Drawing.Point(651, 203);
            this.axA.Name = "axA";
            this.axA.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axA.OcxState")));
            this.axA.Size = new System.Drawing.Size(112, 46);
            this.axA.TabIndex = 15;
            // 
            // axGL1
            // 
            this.axGL1.Enabled = true;
            this.axGL1.Location = new System.Drawing.Point(533, 151);
            this.axGL1.Name = "axGL1";
            this.axGL1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axGL1.OcxState")));
            this.axGL1.Size = new System.Drawing.Size(112, 46);
            this.axGL1.TabIndex = 20;
            // 
            // axAL1
            // 
            this.axAL1.Enabled = true;
            this.axAL1.Location = new System.Drawing.Point(651, 151);
            this.axAL1.Name = "axAL1";
            this.axAL1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axAL1.OcxState")));
            this.axAL1.Size = new System.Drawing.Size(112, 46);
            this.axAL1.TabIndex = 19;
            // 
            // axBL1
            // 
            this.axBL1.Enabled = true;
            this.axBL1.Location = new System.Drawing.Point(769, 151);
            this.axBL1.Name = "axBL1";
            this.axBL1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axBL1.OcxState")));
            this.axBL1.Size = new System.Drawing.Size(112, 46);
            this.axBL1.TabIndex = 18;
            // 
            // axB
            // 
            this.axB.Enabled = true;
            this.axB.Location = new System.Drawing.Point(769, 203);
            this.axB.Name = "axB";
            this.axB.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axB.OcxState")));
            this.axB.Size = new System.Drawing.Size(112, 46);
            this.axB.TabIndex = 21;
            // 
            // axF
            // 
            this.axF.Enabled = true;
            this.axF.Location = new System.Drawing.Point(415, 203);
            this.axF.Name = "axF";
            this.axF.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axF.OcxState")));
            this.axF.Size = new System.Drawing.Size(112, 46);
            this.axF.TabIndex = 22;
            // 
            // btnSHT
            // 
            this.btnSHT.Location = new System.Drawing.Point(8, 540);
            this.btnSHT.Name = "btnSHT";
            this.btnSHT.Size = new System.Drawing.Size(57, 23);
            this.btnSHT.TabIndex = 24;
            this.btnSHT.Text = "上海滩";
            this.btnSHT.UseVisualStyleBackColor = true;
            this.btnSHT.Click += new System.EventHandler(this.btnSHT_Click);
            // 
            // btnYXDCB
            // 
            this.btnYXDCB.Location = new System.Drawing.Point(71, 540);
            this.btnYXDCB.Name = "btnYXDCB";
            this.btnYXDCB.Size = new System.Drawing.Size(80, 23);
            this.btnYXDCB.TabIndex = 25;
            this.btnYXDCB.Text = "隐形的翅膀";
            this.btnYXDCB.UseVisualStyleBackColor = true;
            this.btnYXDCB.Click += new System.EventHandler(this.btnYXDCB_Click);
            // 
            // axCL1
            // 
            this.axCL1.Enabled = true;
            this.axCL1.Location = new System.Drawing.Point(61, 150);
            this.axCL1.Name = "axCL1";
            this.axCL1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axCL1.OcxState")));
            this.axCL1.Size = new System.Drawing.Size(112, 46);
            this.axCL1.TabIndex = 30;
            // 
            // axDL1
            // 
            this.axDL1.Enabled = true;
            this.axDL1.Location = new System.Drawing.Point(179, 151);
            this.axDL1.Name = "axDL1";
            this.axDL1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axDL1.OcxState")));
            this.axDL1.Size = new System.Drawing.Size(112, 46);
            this.axDL1.TabIndex = 29;
            // 
            // axEL1
            // 
            this.axEL1.Enabled = true;
            this.axEL1.Location = new System.Drawing.Point(297, 150);
            this.axEL1.Name = "axEL1";
            this.axEL1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axEL1.OcxState")));
            this.axEL1.Size = new System.Drawing.Size(112, 46);
            this.axEL1.TabIndex = 28;
            // 
            // axFL1
            // 
            this.axFL1.Enabled = true;
            this.axFL1.Location = new System.Drawing.Point(415, 151);
            this.axFL1.Name = "axFL1";
            this.axFL1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axFL1.OcxState")));
            this.axFL1.Size = new System.Drawing.Size(112, 46);
            this.axFL1.TabIndex = 27;
            // 
            // axFH1
            // 
            this.axFH1.Enabled = true;
            this.axFH1.Location = new System.Drawing.Point(415, 256);
            this.axFH1.Name = "axFH1";
            this.axFH1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axFH1.OcxState")));
            this.axFH1.Size = new System.Drawing.Size(112, 46);
            this.axFH1.TabIndex = 45;
            // 
            // axBH1
            // 
            this.axBH1.Enabled = true;
            this.axBH1.Location = new System.Drawing.Point(769, 256);
            this.axBH1.Name = "axBH1";
            this.axBH1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axBH1.OcxState")));
            this.axBH1.Size = new System.Drawing.Size(112, 46);
            this.axBH1.TabIndex = 44;
            // 
            // axGH1
            // 
            this.axGH1.Enabled = true;
            this.axGH1.Location = new System.Drawing.Point(533, 256);
            this.axGH1.Name = "axGH1";
            this.axGH1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axGH1.OcxState")));
            this.axGH1.Size = new System.Drawing.Size(112, 46);
            this.axGH1.TabIndex = 43;
            // 
            // axAH1
            // 
            this.axAH1.Enabled = true;
            this.axAH1.Location = new System.Drawing.Point(651, 256);
            this.axAH1.Name = "axAH1";
            this.axAH1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axAH1.OcxState")));
            this.axAH1.Size = new System.Drawing.Size(112, 46);
            this.axAH1.TabIndex = 42;
            // 
            // axEH1
            // 
            this.axEH1.Enabled = true;
            this.axEH1.Location = new System.Drawing.Point(297, 256);
            this.axEH1.Name = "axEH1";
            this.axEH1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axEH1.OcxState")));
            this.axEH1.Size = new System.Drawing.Size(112, 46);
            this.axEH1.TabIndex = 41;
            // 
            // axDH1
            // 
            this.axDH1.Enabled = true;
            this.axDH1.Location = new System.Drawing.Point(179, 255);
            this.axDH1.Name = "axDH1";
            this.axDH1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axDH1.OcxState")));
            this.axDH1.Size = new System.Drawing.Size(112, 46);
            this.axDH1.TabIndex = 40;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.SystemColors.Desktop;
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox2.ForeColor = System.Drawing.SystemColors.Window;
            this.textBox2.Location = new System.Drawing.Point(9, 1);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(871, 57);
            this.textBox2.TabIndex = 46;
            this.textBox2.Text = resources.GetString("textBox2.Text");
            // 
            // axCL2
            // 
            this.axCL2.Enabled = true;
            this.axCL2.Location = new System.Drawing.Point(61, 98);
            this.axCL2.Name = "axCL2";
            this.axCL2.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axCL2.OcxState")));
            this.axCL2.Size = new System.Drawing.Size(112, 46);
            this.axCL2.TabIndex = 53;
            // 
            // axDL2
            // 
            this.axDL2.Enabled = true;
            this.axDL2.Location = new System.Drawing.Point(179, 98);
            this.axDL2.Name = "axDL2";
            this.axDL2.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axDL2.OcxState")));
            this.axDL2.Size = new System.Drawing.Size(112, 46);
            this.axDL2.TabIndex = 52;
            // 
            // axEL2
            // 
            this.axEL2.Enabled = true;
            this.axEL2.Location = new System.Drawing.Point(297, 98);
            this.axEL2.Name = "axEL2";
            this.axEL2.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axEL2.OcxState")));
            this.axEL2.Size = new System.Drawing.Size(112, 46);
            this.axEL2.TabIndex = 51;
            // 
            // axFL2
            // 
            this.axFL2.Enabled = true;
            this.axFL2.Location = new System.Drawing.Point(415, 98);
            this.axFL2.Name = "axFL2";
            this.axFL2.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axFL2.OcxState")));
            this.axFL2.Size = new System.Drawing.Size(112, 46);
            this.axFL2.TabIndex = 50;
            // 
            // axGL2
            // 
            this.axGL2.Enabled = true;
            this.axGL2.Location = new System.Drawing.Point(533, 98);
            this.axGL2.Name = "axGL2";
            this.axGL2.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axGL2.OcxState")));
            this.axGL2.Size = new System.Drawing.Size(112, 46);
            this.axGL2.TabIndex = 49;
            // 
            // axAL2
            // 
            this.axAL2.Enabled = true;
            this.axAL2.Location = new System.Drawing.Point(651, 98);
            this.axAL2.Name = "axAL2";
            this.axAL2.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axAL2.OcxState")));
            this.axAL2.Size = new System.Drawing.Size(112, 46);
            this.axAL2.TabIndex = 48;
            // 
            // axBL2
            // 
            this.axBL2.Enabled = true;
            this.axBL2.Location = new System.Drawing.Point(770, 98);
            this.axBL2.Name = "axBL2";
            this.axBL2.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axBL2.OcxState")));
            this.axBL2.Size = new System.Drawing.Size(112, 46);
            this.axBL2.TabIndex = 47;
            // 
            // axEH3
            // 
            this.axEH3.Enabled = true;
            this.axEH3.Location = new System.Drawing.Point(297, 359);
            this.axEH3.Name = "axEH3";
            this.axEH3.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axEH3.OcxState")));
            this.axEH3.Size = new System.Drawing.Size(112, 46);
            this.axEH3.TabIndex = 63;
            // 
            // axDH3
            // 
            this.axDH3.Enabled = true;
            this.axDH3.Location = new System.Drawing.Point(179, 359);
            this.axDH3.Name = "axDH3";
            this.axDH3.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axDH3.OcxState")));
            this.axDH3.Size = new System.Drawing.Size(112, 46);
            this.axDH3.TabIndex = 62;
            // 
            // axCH3
            // 
            this.axCH3.Enabled = true;
            this.axCH3.Location = new System.Drawing.Point(61, 359);
            this.axCH3.Name = "axCH3";
            this.axCH3.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axCH3.OcxState")));
            this.axCH3.Size = new System.Drawing.Size(112, 46);
            this.axCH3.TabIndex = 61;
            // 
            // axFH2
            // 
            this.axFH2.Enabled = true;
            this.axFH2.Location = new System.Drawing.Point(415, 308);
            this.axFH2.Name = "axFH2";
            this.axFH2.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axFH2.OcxState")));
            this.axFH2.Size = new System.Drawing.Size(112, 46);
            this.axFH2.TabIndex = 60;
            // 
            // axBH2
            // 
            this.axBH2.Enabled = true;
            this.axBH2.Location = new System.Drawing.Point(770, 307);
            this.axBH2.Name = "axBH2";
            this.axBH2.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axBH2.OcxState")));
            this.axBH2.Size = new System.Drawing.Size(112, 46);
            this.axBH2.TabIndex = 59;
            // 
            // axGH2
            // 
            this.axGH2.Enabled = true;
            this.axGH2.Location = new System.Drawing.Point(533, 308);
            this.axGH2.Name = "axGH2";
            this.axGH2.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axGH2.OcxState")));
            this.axGH2.Size = new System.Drawing.Size(112, 46);
            this.axGH2.TabIndex = 58;
            // 
            // axAH2
            // 
            this.axAH2.Enabled = true;
            this.axAH2.Location = new System.Drawing.Point(651, 308);
            this.axAH2.Name = "axAH2";
            this.axAH2.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axAH2.OcxState")));
            this.axAH2.Size = new System.Drawing.Size(112, 46);
            this.axAH2.TabIndex = 57;
            // 
            // axEH2
            // 
            this.axEH2.Enabled = true;
            this.axEH2.Location = new System.Drawing.Point(297, 307);
            this.axEH2.Name = "axEH2";
            this.axEH2.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axEH2.OcxState")));
            this.axEH2.Size = new System.Drawing.Size(112, 46);
            this.axEH2.TabIndex = 56;
            // 
            // axDH2
            // 
            this.axDH2.Enabled = true;
            this.axDH2.Location = new System.Drawing.Point(179, 307);
            this.axDH2.Name = "axDH2";
            this.axDH2.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axDH2.OcxState")));
            this.axDH2.Size = new System.Drawing.Size(112, 46);
            this.axDH2.TabIndex = 55;
            // 
            // axCH2
            // 
            this.axCH2.Enabled = true;
            this.axCH2.Location = new System.Drawing.Point(61, 307);
            this.axCH2.Name = "axCH2";
            this.axCH2.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axCH2.OcxState")));
            this.axCH2.Size = new System.Drawing.Size(112, 46);
            this.axCH2.TabIndex = 54;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtMain);
            this.groupBox1.Location = new System.Drawing.Point(9, 413);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(435, 121);
            this.groupBox1.TabIndex = 65;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "主旋律";
            // 
            // txtMain
            // 
            this.txtMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtMain.Location = new System.Drawing.Point(3, 17);
            this.txtMain.Multiline = true;
            this.txtMain.Name = "txtMain";
            this.txtMain.Size = new System.Drawing.Size(429, 101);
            this.txtMain.TabIndex = 66;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtChord);
            this.groupBox2.Location = new System.Drawing.Point(447, 413);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(435, 121);
            this.groupBox2.TabIndex = 66;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "伴奏";
            // 
            // txtChord
            // 
            this.txtChord.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtChord.Location = new System.Drawing.Point(3, 17);
            this.txtChord.Multiline = true;
            this.txtChord.Name = "txtChord";
            this.txtChord.Size = new System.Drawing.Size(429, 101);
            this.txtChord.TabIndex = 66;
            // 
            // timerChord
            // 
            this.timerChord.Tick += new System.EventHandler(this.timerChord_Tick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.Desktop;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label1.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(11, 112);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 21);
            this.label1.TabIndex = 67;
            this.label1.Text = "O 0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.Desktop;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(11, 165);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 21);
            this.label2.TabIndex = 68;
            this.label2.Text = "O 1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.Desktop;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label3.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(11, 217);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 21);
            this.label3.TabIndex = 69;
            this.label3.Text = "O 2";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.SystemColors.Desktop;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label4.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(11, 269);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 21);
            this.label4.TabIndex = 70;
            this.label4.Text = "O 3";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.Desktop;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label5.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(10, 321);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(44, 21);
            this.label5.TabIndex = 71;
            this.label5.Text = "O 4";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.Desktop;
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label6.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(11, 373);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 21);
            this.label6.TabIndex = 72;
            this.label6.Text = "O 5";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.Desktop;
            this.label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label7.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(106, 68);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(22, 21);
            this.label7.TabIndex = 73;
            this.label7.Text = "C";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.Desktop;
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label8.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(224, 68);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(22, 21);
            this.label8.TabIndex = 74;
            this.label8.Text = "D";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.Desktop;
            this.label9.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label9.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(342, 68);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(22, 21);
            this.label9.TabIndex = 75;
            this.label9.Text = "E";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.SystemColors.Desktop;
            this.label10.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label10.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(460, 68);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(22, 21);
            this.label10.TabIndex = 76;
            this.label10.Text = "F";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.SystemColors.Desktop;
            this.label11.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label11.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(578, 68);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(22, 21);
            this.label11.TabIndex = 77;
            this.label11.Text = "G";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.SystemColors.Desktop;
            this.label12.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label12.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(696, 68);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(22, 21);
            this.label12.TabIndex = 78;
            this.label12.Text = "A";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.SystemColors.Desktop;
            this.label13.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label13.Font = new System.Drawing.Font("宋体", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(815, 68);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(22, 21);
            this.label13.TabIndex = 79;
            this.label13.Text = "B";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(892, 567);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.axEH3);
            this.Controls.Add(this.axDH3);
            this.Controls.Add(this.axCH3);
            this.Controls.Add(this.axFH2);
            this.Controls.Add(this.axBH2);
            this.Controls.Add(this.axGH2);
            this.Controls.Add(this.axAH2);
            this.Controls.Add(this.axEH2);
            this.Controls.Add(this.axDH2);
            this.Controls.Add(this.axCH2);
            this.Controls.Add(this.axCL2);
            this.Controls.Add(this.axDL2);
            this.Controls.Add(this.axEL2);
            this.Controls.Add(this.axFL2);
            this.Controls.Add(this.axGL2);
            this.Controls.Add(this.axAL2);
            this.Controls.Add(this.axBL2);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.axFH1);
            this.Controls.Add(this.axBH1);
            this.Controls.Add(this.axGH1);
            this.Controls.Add(this.axAH1);
            this.Controls.Add(this.axEH1);
            this.Controls.Add(this.axDH1);
            this.Controls.Add(this.axCL1);
            this.Controls.Add(this.axDL1);
            this.Controls.Add(this.axEL1);
            this.Controls.Add(this.axFL1);
            this.Controls.Add(this.btnYXDCB);
            this.Controls.Add(this.btnSHT);
            this.Controls.Add(this.axF);
            this.Controls.Add(this.axB);
            this.Controls.Add(this.axGL1);
            this.Controls.Add(this.axAL1);
            this.Controls.Add(this.axBL1);
            this.Controls.Add(this.axCH1);
            this.Controls.Add(this.axG);
            this.Controls.Add(this.axA);
            this.Controls.Add(this.axE);
            this.Controls.Add(this.axD);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.axC);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "钢琴模拟播放器";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.axC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axCH1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axG)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axGL1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axAL1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axBL1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axF)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axCL1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDL1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axEL1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axFL1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axFH1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axBH1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axGH1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axAH1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axEH1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDH1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axCL2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDL2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axEL2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axFL2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axGL2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axAL2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axBL2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axEH3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDH3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axCH3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axFH2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axBH2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axGH2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axAH2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axEH2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axDH2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axCH2)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private AxWMPLib.AxWindowsMediaPlayer axC;
        private System.Windows.Forms.Timer timerMain;
        private System.Windows.Forms.Button button11;
        private AxWMPLib.AxWindowsMediaPlayer axD;
        private AxWMPLib.AxWindowsMediaPlayer axE;
        private AxWMPLib.AxWindowsMediaPlayer axCH1;
        private AxWMPLib.AxWindowsMediaPlayer axG;
        private AxWMPLib.AxWindowsMediaPlayer axA;
        private AxWMPLib.AxWindowsMediaPlayer axGL1;
        private AxWMPLib.AxWindowsMediaPlayer axAL1;
        private AxWMPLib.AxWindowsMediaPlayer axBL1;
        private AxWMPLib.AxWindowsMediaPlayer axB;
        private AxWMPLib.AxWindowsMediaPlayer axF;
        private System.Windows.Forms.Button btnSHT;
        private System.Windows.Forms.Button btnYXDCB;
        private AxWMPLib.AxWindowsMediaPlayer axCL1;
        private AxWMPLib.AxWindowsMediaPlayer axDL1;
        private AxWMPLib.AxWindowsMediaPlayer axEL1;
        private AxWMPLib.AxWindowsMediaPlayer axFL1;
        private AxWMPLib.AxWindowsMediaPlayer axFH1;
        private AxWMPLib.AxWindowsMediaPlayer axBH1;
        private AxWMPLib.AxWindowsMediaPlayer axGH1;
        private AxWMPLib.AxWindowsMediaPlayer axAH1;
        private AxWMPLib.AxWindowsMediaPlayer axEH1;
        private AxWMPLib.AxWindowsMediaPlayer axDH1;
        private System.Windows.Forms.TextBox textBox2;
        private AxWMPLib.AxWindowsMediaPlayer axCL2;
        private AxWMPLib.AxWindowsMediaPlayer axDL2;
        private AxWMPLib.AxWindowsMediaPlayer axEL2;
        private AxWMPLib.AxWindowsMediaPlayer axFL2;
        private AxWMPLib.AxWindowsMediaPlayer axGL2;
        private AxWMPLib.AxWindowsMediaPlayer axAL2;
        private AxWMPLib.AxWindowsMediaPlayer axBL2;
        private AxWMPLib.AxWindowsMediaPlayer axEH3;
        private AxWMPLib.AxWindowsMediaPlayer axDH3;
        private AxWMPLib.AxWindowsMediaPlayer axCH3;
        private AxWMPLib.AxWindowsMediaPlayer axFH2;
        private AxWMPLib.AxWindowsMediaPlayer axBH2;
        private AxWMPLib.AxWindowsMediaPlayer axGH2;
        private AxWMPLib.AxWindowsMediaPlayer axAH2;
        private AxWMPLib.AxWindowsMediaPlayer axEH2;
        private AxWMPLib.AxWindowsMediaPlayer axDH2;
        private AxWMPLib.AxWindowsMediaPlayer axCH2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtMain;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtChord;
        private System.Windows.Forms.Timer timerChord;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
    }
}

