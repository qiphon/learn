﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AnimalLibrary
{
    public interface IChange
    {
        string ChangeThing(string thing);
    }
}
